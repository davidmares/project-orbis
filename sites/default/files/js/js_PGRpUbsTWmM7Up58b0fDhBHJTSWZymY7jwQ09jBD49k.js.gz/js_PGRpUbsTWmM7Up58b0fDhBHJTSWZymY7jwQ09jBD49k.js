(function ($) {
	Drupal.behaviors.OrbisBehavior = {
	  attach: function (context) {

	  	$(".alert-block").hide();

	  }
	};
})(jQuery);;
